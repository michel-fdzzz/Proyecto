<?php
session_start();
$_SESSION['idCliente'] = null;
